import express from 'express';
import cors from 'cors';
import {createServer} from 'node:http';
import {Server} from 'socket.io';
import crypto from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

type Card={id:string;name:string;cost:number;type:'attack'|'skill'|'power';damage?:number;block?:number;effect?:'draw'|'strength'|'poison';desc:string};
type Enemy={id:string;name:string;hp:number;maxHp:number;intent:number;poison:number};
type Player={id:string;name:string;hp:number;maxHp:number;block:number;energy:number;maxEnergy:number;strength:number;poison:number;deck:Card[];draw:Card[];hand:Card[];discard:Card[];gold:number;ended:boolean};
type Game={id:string;seed:number;phase:'lobby'|'battle'|'reward'|'won'|'lost';turn:number;players:Record<string,Player>;enemy:Enemy;log:string[];reward?:Card[]};

const cards:Card[]=[
{id:'jab',name:'Jab',cost:1,type:'attack',damage:6,desc:'Deal 6 damage.'},
{id:'guard',name:'Guard',cost:1,type:'skill',block:6,desc:'Gain 6 Block.'},
{id:'ember',name:'Ember Bolt',cost:1,type:'attack',damage:9,desc:'Deal 9 damage.'},
{id:'insight',name:'Insight',cost:0,type:'skill',effect:'draw',desc:'Draw 2 cards.'},
{id:'fortify',name:'Fortify',cost:2,type:'skill',block:12,desc:'Gain 12 Block.'},
{id:'venom',name:'Venom Edge',cost:1,type:'attack',damage:3,effect:'poison',desc:'Deal 3 damage and apply 3 Poison.'},
{id:'focus',name:'Battle Focus',cost:1,type:'power',effect:'strength',desc:'Gain 2 Strength.'},
{id:'flare',name:'Flare Burst',cost:2,type:'attack',damage:16,desc:'Deal 16 damage.'}
];
const clone=(c:Card)=>({...c});
const baseDeck=()=>[...Array(5)].map(()=>clone(cards[0])).concat([...Array(4)].map(()=>clone(cards[1])),[clone(cards[2])]);
const shuffle=<T,>(a:T[],r=Math.random)=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const rng=(seed:number)=>{let x=seed>>>0;return()=>((x=x*1664525+1013904223>>>0)/4294967296)};
const games=new Map<string,Game>();
function makePlayer(id:string,name:string):Player{return{id,name,hp:70,maxHp:70,block:0,energy:3,maxEnergy:3,strength:0,poison:0,deck:baseDeck(),draw:[],hand:[],discard:[],gold:99,ended:false}}
function makeEnemy(seed:number):Enemy{const r=rng(seed);return{id:'warden',name:'Ash Warden',hp:80,maxHp:80,intent:8+Math.floor(r()*5),poison:0}}
function startTurn(g:Game){g.turn++;for(const p of Object.values(g.players)){p.block=0;p.energy=p.maxEnergy;p.ended=false;p.hand=[];if(!p.draw.length)p.draw=shuffle(p.discard.splice(0),rng(g.seed+g.turn+p.id.length));while(p.hand.length<5&&p.draw.length)p.hand.push(p.draw.pop()!)}g.log.push(`Round ${g.turn}: the party draws.`)}
function startBattle(g:Game){for(const p of Object.values(g.players)){p.draw=shuffle(p.deck.slice(),rng(g.seed+p.id.length+g.turn));p.discard=[];p.hand=[];p.ended=false}g.enemy=makeEnemy(g.seed+g.turn);g.phase='battle';startTurn(g)}
function alive(g:Game){return Object.values(g.players).filter(p=>p.hp>0)}
function publicState(g:Game){return{...g,players:Object.fromEntries(Object.entries(g.players).map(([id,p])=>[id,{...p,deck:p.deck.map(c=>c.id),draw:undefined,discard:undefined,exhaust:undefined,drawCount:p.draw.length,discardCount:p.discard.length}]))}}
function finishReward(g:Game){g.phase='reward';g.reward=[clone(cards[4]),clone(cards[5]),clone(cards[6]),clone(cards[7])];g.log.push('A boon appears. One player must choose it.')}
function play(g:Game,p:Player,id:string){if(g.phase!=='battle'||p.ended)return;if(p.hp<=0)return;const c=p.hand.find(x=>x.id===id);if(!c||p.energy<c.cost)return;p.energy-=c.cost;p.hand=p.hand.filter(x=>x!==c);p.discard.push(c);if(c.damage){const d=c.damage+p.strength;g.enemy.hp=Math.max(0,g.enemy.hp-d);g.log.push(`${p.name} used ${c.name} for ${d} damage.`)}if(c.block)p.block+=c.block;if(c.effect==='draw')for(let i=0;i<2;i++)if(p.draw.length)p.hand.push(p.draw.pop()!);if(c.effect==='strength')p.strength+=2;if(c.effect==='poison')g.enemy.poison+=3;if(g.enemy.hp<=0)finishReward(g)}
function endTurn(g:Game,p:Player){if(g.phase!=='battle'||p.ended)return;p.ended=true;if(Object.values(g.players).every(x=>x.ended)){const enemyDamage=Math.max(0,g.enemy.intent);for(const x of Object.values(g.players)){const taken=Math.max(0,enemyDamage-x.block);x.hp-=taken;if(x.poison){x.hp-=x.poison;x.poison=0}}if(!alive(g).length){g.phase='lost';g.log.push('The party fell.')}else if(g.enemy.hp<=0){finishReward(g)}else{if(g.enemy.poison){g.enemy.hp=Math.max(0,g.enemy.hp-g.enemy.poison);g.enemy.poison=Math.max(0,g.enemy.poison-1)}g.enemy.intent=7+Math.floor(rng(g.seed+g.turn+1)()*8);startTurn(g)}}}
function createGame(id:string,name:string){const seed=Date.now()>>>0;const g:Game={id:crypto.randomBytes(3).toString('hex').toUpperCase(),seed,phase:'lobby',turn:0,players:{},enemy:makeEnemy(seed),log:['Room created.']};g.players[id]=makePlayer(id,name);games.set(g.id,g);return g}

const app=express();app.use(cors({origin:true,credentials:true}));app.get('/health',(_,res)=>res.json({ok:true,rooms:games.size}));
const dist=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../public');app.use(express.static(dist));
const http=createServer(app);const io=new Server(http,{cors:{origin:true,credentials:true}});
const roomFor=(id:string)=>[...games.values()].find(g=>g.players[id]);
function emit(g:Game){io.to(g.id).emit('state',publicState(g))}
io.on('connection',s=>{
 s.on('create',({name},cb)=>{const g=createGame(s.id,String(name||'Wanderer').slice(0,18));s.join(g.id);cb?.({room:g.id});emit(g)});
 s.on('join',({room,name},cb)=>{const g=games.get(String(room||'').toUpperCase());if(!g||g.phase!=='lobby'||Object.keys(g.players).length>=4)return cb?.({error:'That room is unavailable.'});g.players[s.id]=makePlayer(s.id,String(name||'Wanderer').slice(0,18));s.join(g.id);g.log.push(`${g.players[s.id].name} joined the party.`);cb?.({room:g.id});emit(g)});
 s.on('start',()=>{const g=roomFor(s.id);if(!g)return;if(Object.keys(g.players)[0]!==s.id)return s.emit('notice','Only the host can start.');if(Object.keys(g.players).length<2)return s.emit('notice','At least 2 players are required.');startBattle(g);emit(g)});
 s.on('play',({cardId})=>{const g=roomFor(s.id);if(!g)return;play(g,g.players[s.id],String(cardId));emit(g)});
 s.on('endTurn',()=>{const g=roomFor(s.id);if(!g)return;endTurn(g,g.players[s.id]);emit(g)});
 s.on('reward',({cardId})=>{const g=roomFor(s.id);if(!g||g.phase!=='reward'||!g.reward)return;const c=g.reward.find(x=>x.id===String(cardId));if(!c)return;g.players[s.id].deck.push(clone(c));g.log.push(`${g.players[s.id].name} added ${c.name} to their deck.`);g.reward=undefined;if(g.turn>=3){g.phase='won';g.log.push('The Ember Gate opens. Run complete!')}else startBattle(g);emit(g)});
 s.on('disconnect',()=>{for(const g of games.values())if(g.players[s.id]){const name=g.players[s.id].name;delete g.players[s.id];g.log.push(`${name} left the party.`);if(Object.keys(g.players).length)emit(g);else games.delete(g.id)}});
});
const port=Number(process.env.PORT||3001);http.listen(port,()=>console.log(`Emberfall server listening on ${port}`));
