import { io } from 'socket.io-client';
import './style.css';

type Card={id:string;name:string;cost:number;type:string;damage?:number;block?:number;effect?:string;desc:string};
type Player={id:string;name:string;hp:number;maxHp:number;block:number;energy:number;maxEnergy:number;strength:number;poison:number;hand:Card[];drawCount:number;discardCount:number;deck:string[];gold:number;ended:boolean};
type State={id:string;phase:string;turn:number;players:Record<string,Player>;enemy:{name:string;hp:number;maxHp:number;intent:number;poison:number};log:string[];reward?:Card[]};

const socket=io(import.meta.env.VITE_SERVER_URL || undefined,{autoConnect:true});
let me=''; let state:State|null=null; let notice='';
const root=document.querySelector('#root')!;
const esc=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const setNotice=(s:string)=>{notice=s;render();setTimeout(()=>{if(notice===s){notice='';render()}},3500)};
function card(c:Card,kind:'play'|'reward'){return `<button class="card ${c.type}" data-${kind}="${c.id}" ${kind==='play' && ((state?.players[me]?.ended)||(state?.players[me]?.energy ?? 0)<c.cost)?'disabled':''}><span class="cost">${c.cost}</span><strong>${esc(c.name)}</strong><small>${esc(c.type.toUpperCase())}</small><p>${esc(c.desc)}</p></button>`}
function render(){
 if(!state){root.innerHTML=`<main class="landing"><div class="brand"><div class="sigil">✦</div><h1>EMBERFALL</h1><p>Cooperative deckbuilding in a living, burning world.</p></div><section class="lobby-card"><label>Your name<input id="name" maxlength="18" placeholder="Wanderer"></label><div class="actions"><button class="primary" id="create">Create a game</button><div class="join"><input id="code" maxlength="6" placeholder="ROOM CODE"><button id="join">Join</button></div></div><p class="hint">2–4 players · Real-time · No download required</p></section><footer>Original game inspired by cooperative roguelike deckbuilders.</footer></main>`;
 const name=()=>((document.querySelector('#name') as HTMLInputElement)?.value||'Wanderer').trim();
 document.querySelector('#create')?.addEventListener('click',()=>socket.emit('create',{name},(r:any)=>r.error&&setNotice(r.error)));
 document.querySelector('#join')?.addEventListener('click',()=>socket.emit('join',{name,room:(document.querySelector('#code') as HTMLInputElement).value},(r:any)=>r.error&&setNotice(r.error)));
 return; }
 const mine=state.players[me]; const players=Object.values(state.players); const host=players[0]?.id===me;
 const hpPct=Math.max(0,Math.min(100,100*state.enemy.hp/state.enemy.maxHp));
 root.innerHTML=`<main class="app"><header><div class="wordmark">EMBERFALL</div><div class="room">ROOM <b>${state.id}</b><button id="copy">Copy code</button></div></header>
 <div class="notice">${notice?esc(notice):''}</div>
 <section class="battle-layout"><div class="arena"><div class="turnline"><span>ROUND ${state.turn||'—'}</span><span class="phase">${state.phase.toUpperCase()}</span></div>
 <div class="enemy-card"><div class="enemy-icon">☄</div><h2>${esc(state.enemy.name)}</h2><div class="hpbar"><i style="width:${hpPct}%"></i></div><b>${state.enemy.hp} / ${state.enemy.maxHp}</b><div class="intent">INTENT <strong>⚔ ${state.enemy.intent}</strong></div>${state.enemy.poison?`<div class="status">☠ Poison ${state.enemy.poison}</div>`:''}</div>
 ${state.phase==='lobby'?`<div class="center-panel"><h2>Gather your party</h2><p>Share room code <b>${state.id}</b> with your allies.</p><p>${players.length}/4 players ready</p>${players.map(p=>`<div class="party-row"><span>${p.id===me?'You · ':''}${esc(p.name)}</span><span>${p.id===players[0]?.id?'HOST':''}</span></div>`).join('')}<button class="primary big" id="start" ${!host||players.length<2?'disabled':''}>${players.length<2?'Need 2 players':'Begin expedition'}</button></div>`:''}
 ${state.phase==='reward'?`<div class="center-panel"><h2>Choose a boon</h2><p>Your choice is added to your deck. The party continues when you choose.</p><div class="cards">${(state.reward||[]).map(c=>card(c,'reward')).join('')}</div></div>`:''}
 ${state.phase==='battle'?`<div class="hand-panel"><div class="hand-head"><h2>Your hand</h2><span>${mine.energy} / ${mine.maxEnergy} <em>ENERGY</em></span></div><div class="cards">${mine.hand.map(c=>card(c,'play')).join('')}</div><button class="end" id="end" ${mine.ended?'disabled':''}>${mine.ended?'Turn ended':'End my turn'}</button></div>`:''}
 ${state.phase==='won'?`<div class="center-panel victory"><div class="big-icon">✦</div><h2>The Ember Gate opens</h2><p>Your party survived the expedition.</p><button class="primary" id="leave">Return to lobby</button></div>`:''}
 ${state.phase==='lost'?`<div class="center-panel defeat"><div class="big-icon">☠</div><h2>The expedition falls</h2><p>The Ash Warden was too much for the party.</p><button class="primary" id="leave">Return to lobby</button></div>`:''}
 </div><aside class="sidebar"><h3>PARTY</h3>${players.map(p=>`<div class="player ${p.id===me?'you':''}"><div class="avatar">${esc(p.name[0]||'?')}</div><div class="pinfo"><b>${esc(p.name)}</b><div class="mini-bar"><i style="width:${100*p.hp/p.maxHp}%"></i></div><small>${p.hp}/${p.maxHp} HP · ${p.block} Block</small></div><span class="energy">${p.energy}⚡</span></div>`).join('')}<div class="deck-stats"><span>Draw ${mine?.drawCount??0}</span><span>Discard ${mine?.discardCount??0}</span><span>Deck ${mine?.deck.length??0}</span></div><h3>COMBAT LOG</h3><div class="log">${state.log.slice(-12).reverse().map(x=>`<div>${esc(x)}</div>`).join('')}</div></aside></section></main>`;
 document.querySelector('#copy')?.addEventListener('click',async()=>{await navigator.clipboard?.writeText(state!.id);setNotice('Room code copied.');});
 document.querySelector('#start')?.addEventListener('click',()=>socket.emit('start'));
 document.querySelector('#end')?.addEventListener('click',()=>socket.emit('endTurn'));
 document.querySelector('#leave')?.addEventListener('click',()=>{location.reload()});
 document.querySelectorAll('[data-play]').forEach(x=>x.addEventListener('click',()=>socket.emit('play',{cardId:(x as HTMLElement).dataset.play})));
 document.querySelectorAll('[data-reward]').forEach(x=>x.addEventListener('click',()=>socket.emit('reward',{cardId:(x as HTMLElement).dataset.reward})));
}
socket.on('connect',()=>{me=socket.id!;render()}); socket.on('state',(s:State)=>{state=s;render()}); socket.on('notice',(s:string)=>setNotice(s)); socket.on('connect_error',()=>setNotice('Could not connect to the game server.'));
render();
